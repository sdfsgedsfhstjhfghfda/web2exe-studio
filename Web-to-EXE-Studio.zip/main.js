const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs-extra');
const AdmZip = require('adm-zip');
const builder = require('electron-builder');

let mainWindow = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 850,
    minWidth: 900,
    minHeight: 650,
    backgroundColor: '#0b0f19',
    title: 'Web2Exe Studio - Web Sitelerini Windows EXE Uygulamasına Dönüştürücü',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  Menu.setApplicationMenu(null);
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

/* --------------------------------------------------------------------------
 * IPC Handlers & Dialogs
 * -------------------------------------------------------------------------- */

// Desktop yolu
ipcMain.handle('system:getDesktopPath', () => {
  return app.getPath('desktop');
});

// Dosya Seçme (HTML veya ZIP)
ipcMain.handle('dialog:openFile', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Web Dosyası veya ZIP Arşivi Seç',
    properties: ['openFile'],
    filters: [
      { name: 'Desteklenen Web Dosyaları (*.html, *.htm, *.zip)', extensions: ['html', 'htm', 'zip'] },
      { name: 'HTML Dosyaları (*.html, *.htm)', extensions: ['html', 'htm'] },
      { name: 'ZIP Arşivleri (*.zip)', extensions: ['zip'] },
      { name: 'Tüm Dosyalar (*.*)', extensions: ['*'] }
    ]
  });

  if (result.canceled || result.filePaths.length === 0) return null;
  return result.filePaths[0];
});

// Klasör Seçme
ipcMain.handle('dialog:openFolder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Web Sitesi / Proje Klasörü Seç',
    properties: ['openDirectory']
  });

  if (result.canceled || result.filePaths.length === 0) return null;
  return result.filePaths[0];
});

// Çıktı Klasörü Seçme
ipcMain.handle('dialog:openOutputDir', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'EXE Kayıt Konumunu Seç',
    defaultPath: app.getPath('desktop'),
    properties: ['openDirectory']
  });

  if (result.canceled || result.filePaths.length === 0) return null;
  return result.filePaths[0];
});

// Shell: EXE'yi Çalıştır
ipcMain.handle('shell:openExe', async (event, exePath) => {
  if (fs.existsSync(exePath)) {
    shell.openPath(exePath);
    return true;
  }
  return false;
});

// Shell: Klasörde Göster
ipcMain.handle('shell:showInFolder', async (event, filePath) => {
  if (fs.existsSync(filePath)) {
    shell.showItemInFolder(filePath);
    return true;
  }
  return false;
});

/* --------------------------------------------------------------------------
 * Akıllı Dosya Doğrulama & Analiz Motoru
 * -------------------------------------------------------------------------- */
ipcMain.handle('project:validate', async (event, targetPath) => {
  try {
    if (!targetPath || !fs.existsSync(targetPath)) {
      return { valid: false, error: 'Seçilen dosya veya klasör bulunamadı.' };
    }

    const stat = fs.statSync(targetPath);

    // 1. Durum: Tekil Dosya
    if (stat.isFile()) {
      const ext = path.extname(targetPath).toLowerCase();
      const baseName = path.basename(targetPath, ext);

      // ZIP Arşivi Doğrulama
      if (ext === '.zip') {
        try {
          const zip = new AdmZip(targetPath);
          const zipEntries = zip.getEntries();

          let hasHtml = false;
          let htmlEntry = null;
          let totalFiles = 0;
          let scriptsCount = 0;
          let cssCount = 0;
          let imagesCount = 0;

          for (const entry of zipEntries) {
            if (!entry.isDirectory) {
              totalFiles++;
              const entryExt = path.extname(entry.entryName).toLowerCase();
              if (entryExt === '.html' || entryExt === '.htm') {
                hasHtml = true;
                if (!htmlEntry || entry.name.toLowerCase() === 'index.html') {
                  htmlEntry = entry.entryName;
                }
              } else if (entryExt === '.js') {
                scriptsCount++;
              } else if (entryExt === '.css') {
                cssCount++;
              } else if (['.png', '.jpg', '.jpeg', '.svg', '.webp', '.gif', '.ico'].includes(entryExt)) {
                imagesCount++;
              }
            }
          }

          if (!hasHtml) {
            return {
              valid: false,
              error: '❌ ZIP arşivi içinde herhangi bir .html dosyası bulunamadı! Lütfen web dosyaları içeren bir arşiv seçin.'
            };
          }

          return {
            valid: true,
            type: 'zip',
            sourcePath: targetPath,
            detectedName: cleanAppName(baseName),
            entryHtml: htmlEntry,
            totalFiles,
            scriptsCount,
            cssCount,
            imagesCount,
            details: `ZIP Arşivi (${totalFiles} dosya, ana sayfa: ${htmlEntry})`
          };
        } catch (zipErr) {
          return {
            valid: false,
            error: '❌ ZIP arşivi okunamadı veya bozuk: ' + zipErr.message
          };
        }
      }

      // HTML Dosyası Doğrulama
      if (ext === '.html' || ext === '.htm') {
        const content = fs.readFileSync(targetPath, 'utf8');
        let detectedTitle = baseName;
        const titleMatch = content.match(/<title>([^<]*)<\/title>/i);
        if (titleMatch && titleMatch[1].trim()) {
          detectedTitle = titleMatch[1].trim();
        }

        return {
          valid: true,
          type: 'single_html',
          sourcePath: targetPath,
          detectedName: cleanAppName(detectedTitle),
          entryHtml: path.basename(targetPath),
          totalFiles: 1,
          scriptsCount: (content.match(/<script/gi) || []).length,
          cssCount: (content.match(/<link|<style/gi) || []).length,
          imagesCount: (content.match(/<img/gi) || []).length,
          details: `Tekil Web Sayfası (${ext.toUpperCase()})`
        };
      }

      // Desteklenmeyen Dosya Türü Uyarısı
      return {
        valid: false,
        error: `⚠️ "${ext}" dosya türü bunu karşılamıyor!\n\nSadece .html / .htm web sayfaları, web klasörleri veya .zip arşivleri Windows uygulamasına dönüştürülebilir.`
      };
    }

    // 2. Durum: Klasör Doğrulama
    if (stat.isDirectory()) {
      const folderName = path.basename(targetPath);
      const files = await getAllFilesRecursively(targetPath);

      let hasHtml = false;
      let htmlPath = null;
      let scriptsCount = 0;
      let cssCount = 0;
      let imagesCount = 0;

      for (const file of files) {
        const ext = path.extname(file).toLowerCase();
        const rel = path.relative(targetPath, file);
        if (ext === '.html' || ext === '.htm') {
          hasHtml = true;
          if (!htmlPath || path.basename(file).toLowerCase() === 'index.html') {
            htmlPath = rel;
          }
        } else if (ext === '.js') {
          scriptsCount++;
        } else if (ext === '.css') {
          cssCount++;
        } else if (['.png', '.jpg', '.jpeg', '.svg', '.webp', '.gif', '.ico'].includes(ext)) {
          imagesCount++;
        }
      }

      if (!hasHtml) {
        return {
          valid: false,
          error: '❌ Seçilen klasör içinde index.html veya herhangi bir .html sayfası bulunamadı!\n\nLütfen içinde web sayfalarınızın olduğu bir klasör seçin.'
        };
      }

      return {
        valid: true,
        type: 'folder',
        sourcePath: targetPath,
        detectedName: cleanAppName(folderName),
        entryHtml: htmlPath,
        totalFiles: files.length,
        scriptsCount,
        cssCount,
        imagesCount,
        details: `Web Proje Klasörü (${files.length} dosya, giriş: ${htmlPath})`
      };
    }

    return { valid: false, error: 'Geçersiz dosya türü.' };
  } catch (err) {
    return { valid: false, error: 'Dosya analizi sırasında hata oluştu: ' + err.message };
  }
});

/* --------------------------------------------------------------------------
 * Otomatik Proje Oluşturma & Electron EXE Paketleme Motoru
 * -------------------------------------------------------------------------- */
ipcMain.handle('project:build', async (event, options) => {
  const {
    sourcePath,
    sourceType,
    appName,
    windowWidth = 1280,
    windowHeight = 800,
    isFullscreen = false,
    hideMenuBar = true,
    outputDir = app.getPath('desktop')
  } = options;

  const log = (msg) => {
    event.sender.send('build:log', msg);
  };

  try {
    log(`🚀 [1/4] Derleme Başlatılıyor: "${appName}"`);
    log(`📂 Kaynak: ${sourcePath}`);

    const safeSlug = appName.toLowerCase().replace(/[^a-z0-9_-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '') || 'app';
    const tempRoot = path.join(app.getPath('temp'), `web2exe_${Date.now()}`);
    const projectDir = path.join(tempRoot, safeSlug);

    await fs.ensureDir(projectDir);
    log(`📦 [2/4] Çalışma alanı hazırlanıyor: ${projectDir}`);

    let entryHtmlName = 'index.html';

    // 1. Dosyaları kopyala / çıkar
    if (sourceType === 'single_html') {
      const targetHtml = path.join(projectDir, 'index.html');
      await fs.copy(sourcePath, targetHtml);
      log(`📄 Tekil HTML index.html olarak yerleştirildi.`);
    } else if (sourceType === 'zip') {
      log(`📦 ZIP arşivi açılıyor...`);
      const zip = new AdmZip(sourcePath);
      zip.extractAllTo(projectDir, true);

      // Giriş HTML'ini kontrol et
      if (!fs.existsSync(path.join(projectDir, 'index.html'))) {
        const all = await getAllFilesRecursively(projectDir);
        const firstHtml = all.find(f => ['.html', '.htm'].includes(path.extname(f).toLowerCase()));
        if (firstHtml) {
          entryHtmlName = path.relative(projectDir, firstHtml).replace(/\\/g, '/');
        }
      }
      log(`✅ ZIP başarıyla çalışma alanına açıldı.`);
    } else if (sourceType === 'folder') {
      log(`📁 Klasör dosyaları kopyalanıyor...`);
      await fs.copy(sourcePath, projectDir, {
        filter: (src) => !src.includes('node_modules') && !src.includes('.git') && !src.includes('dist')
      });

      if (!fs.existsSync(path.join(projectDir, 'index.html'))) {
        const all = await getAllFilesRecursively(projectDir);
        const firstHtml = all.find(f => ['.html', '.htm'].includes(path.extname(f).toLowerCase()));
        if (firstHtml) {
          entryHtmlName = path.relative(projectDir, firstHtml).replace(/\\/g, '/');
        }
      }
      log(`✅ Dosyalar kopyalandı.`);
    }

    // 2. Otomatik main.js Üretimi (Self-Healing)
    log(`🛠️ [3/4] Electron yapılandırması otomatik oluşturuluyor...`);
    const generatedMainJs = `
const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: ${parseInt(windowWidth, 10) || 1280},
    height: ${parseInt(windowHeight, 10) || 800},
    minWidth: 800,
    minHeight: 500,
    fullscreen: ${isFullscreen ? 'true' : 'false'},
    autoHideMenuBar: ${hideMenuBar ? 'true' : 'false'},
    backgroundColor: '#0f172a',
    title: ${JSON.stringify(appName)},
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });

  win.loadFile(path.join(__dirname, ${JSON.stringify(entryHtmlName)}));

  win.webContents.on('before-input-event', (event, input) => {
    if (input.key === 'F11' && input.type === 'keyDown') {
      win.setFullScreen(!win.isFullScreen());
      event.preventDefault();
    }
  });

  ${hideMenuBar ? 'Menu.setApplicationMenu(null);' : ''}
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
`;
    await fs.writeFile(path.join(projectDir, 'main.js'), generatedMainJs.trim(), 'utf8');

    // 3. Otomatik package.json Üretimi (build alanı OLMADAN - sadece temel bilgiler)
    const generatedPackageJson = {
      name: safeSlug,
      productName: appName,
      version: '1.0.0',
      description: `${appName} - Windows Masaüstü Uygulaması`,
      main: 'main.js',
      author: 'Web2Exe Studio'
    };
    await fs.writeFile(path.join(projectDir, 'package.json'), JSON.stringify(generatedPackageJson, null, 2), 'utf8');

    // 4. Derleyiciyi Electron DIŞINDA ayrı Node.js sürecinde çalıştır (asar sorunu önlenir)
    log(`⚡ [4/4] Windows .EXE Derleniyor (electron-builder)...`);
    log(`⏳ Lütfen bekleyin, taşınabilir EXE sıkıştırılıyor...`);

    const distFolder = path.join(projectDir, 'dist');
    const NODE_EXE = 'C:\\Program Files\\nodejs\\node.exe';
    const WORKER_SCRIPT = path.join(__dirname, 'build-worker.js');

    const builtFiles = await new Promise((resolve, reject) => {
      const child = require('child_process').fork(WORKER_SCRIPT, [], {
        execPath: NODE_EXE,
        cwd: __dirname,
        silent: false
      });

      child.send({
        projectDir,
        distFolder,
        safeSlug,
        appName
      });

      child.on('message', (msg) => {
        if (msg.type === 'log') {
          log(msg.msg);
        } else if (msg.type === 'done') {
          resolve(msg.files);
        } else if (msg.type === 'error') {
          reject(new Error(msg.message));
        }
      });

      child.on('error', (err) => {
        reject(new Error('Worker başlatılamadı: ' + err.message));
      });

      child.on('close', (code) => {
        if (code !== 0 && code !== null) {
          reject(new Error(`Derleme işlemi ${code} koduyla sonlandı.`));
        }
      });
    });

    log(`📦 Oluşturulan dosyalar: ${builtFiles.join(', ')}`);

    // 5. Üretilen EXE'yi Hedef Klasöre (veya Masaüstüne) Kopyala
    const expectedExeName = `${cleanFileName(appName)}-Portable.exe`;
    let finalExePath = path.join(outputDir, expectedExeName);

    let generatedExe = builtFiles.find(f => f.endsWith('.exe'));
    if (!generatedExe) {
      const distFiles = await fs.readdir(distFolder);
      const exeFile = distFiles.find(f => f.endsWith('.exe'));
      if (exeFile) {
        generatedExe = path.join(distFolder, exeFile);
      }
    }

    if (!generatedExe || !fs.existsSync(generatedExe)) {
      throw new Error('EXE dosyası oluşturulamadı veya bulunamadı.');
    }

    await fs.copy(generatedExe, finalExePath, { overwrite: true });
    log(`🎉 [BAŞARILI] Windows .EXE Dosyanız Hazır: ${finalExePath}`);

    fs.remove(tempRoot).catch(() => {});

    return {
      success: true,
      exePath: finalExePath,
      appName: appName
    };

  } catch (err) {
    log(`❌ [HATA] ${err.message}`);
    return {
      success: false,
      error: err.message
    };
  }
});

/* --------------------------------------------------------------------------
 * Yardımcı Fonksiyonlar
 * -------------------------------------------------------------------------- */
async function getAllFilesRecursively(dir) {
  let results = [];
  const list = await fs.readdir(dir);
  for (const file of list) {
    const filePath = path.join(dir, file);
    const stat = await fs.stat(filePath);
    if (stat && stat.isDirectory()) {
      if (!['node_modules', '.git', 'dist'].includes(file)) {
        const res = await getAllFilesRecursively(filePath);
        results = results.concat(res);
      }
    } else {
      results.push(filePath);
    }
  }
  return results;
}

function cleanAppName(name) {
  if (!name) return 'WebUygulamasi';
  return name.replace(/[\\/:*?"<>|]/g, '').trim() || 'WebUygulamasi';
}

function cleanFileName(name) {
  if (!name) return 'Uygulama';
  return name.replace(/[\\/:*?"<>|\s]/g, '-').replace(/-+/g, '-');
}
