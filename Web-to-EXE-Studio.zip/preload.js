const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('api', {
  getPathForFile: (file) => {
    try {
      return webUtils.getPathForFile(file);
    } catch (e) {
      return file.path || '';
    }
  },
  openFileDialog: () => ipcRenderer.invoke('dialog:openFile'),
  openFolderDialog: () => ipcRenderer.invoke('dialog:openFolder'),
  openOutputDirDialog: () => ipcRenderer.invoke('dialog:openOutputDir'),
  validatePath: (targetPath) => ipcRenderer.invoke('project:validate', targetPath),
  buildProject: (options) => ipcRenderer.invoke('project:build', options),
  onBuildLog: (callback) => {
    ipcRenderer.removeAllListeners('build:log');
    ipcRenderer.on('build:log', (event, data) => callback(data));
  },
  openExe: (exePath) => ipcRenderer.invoke('shell:openExe', exePath),
  showInFolder: (filePath) => ipcRenderer.invoke('shell:showInFolder', filePath),
  getDesktopPath: () => ipcRenderer.invoke('system:getDesktopPath')
});
