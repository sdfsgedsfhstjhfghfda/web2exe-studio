/**
 * Web2Exe Studio - Renderer UI Controller
 */

(function () {
  'use strict';

  let currentProject = null;
  let defaultOutputDir = '';
  let generatedExePath = '';

  // DOM Elemanları
  const dropzoneCard = document.getElementById('dropzoneCard');
  const selectFileBtn = document.getElementById('selectFileBtn');
  const selectFolderBtn = document.getElementById('selectFolderBtn');

  const configSection = document.getElementById('configSection');
  const summaryTitle = document.getElementById('summaryTitle');
  const summaryDetails = document.getElementById('summaryDetails');
  const changeFileBtn = document.getElementById('changeFileBtn');

  const appNameInput = document.getElementById('appNameInput');
  const sizePresetSelect = document.getElementById('sizePresetSelect');
  const customWidthInput = document.getElementById('customWidthInput');
  const customHeightInput = document.getElementById('customHeightInput');
  const hideMenuSwitch = document.getElementById('hideMenuSwitch');
  const fullscreenSwitch = document.getElementById('fullscreenSwitch');
  const outputDirInput = document.getElementById('outputDirInput');
  const browseOutputDirBtn = document.getElementById('browseOutputDirBtn');
  const startBuildBtn = document.getElementById('startBuildBtn');

  // Modallar
  const buildModal = document.getElementById('buildModal');
  const buildPhaseText = document.getElementById('buildPhaseText');
  const terminalLog = document.getElementById('terminalLog');

  const successModal = document.getElementById('successModal');
  const successExePath = document.getElementById('successExePath');
  const openExeNowBtn = document.getElementById('openExeNowBtn');
  const showInFolderBtn = document.getElementById('showInFolderBtn');
  const newConversionBtn = document.getElementById('newConversionBtn');

  const errorModal = document.getElementById('errorModal');
  const errorModalMessage = document.getElementById('errorModalMessage');
  const closeErrorModalBtn = document.getElementById('closeErrorModalBtn');

  // Başlangıç: Masaüstü yolunu al
  if (window.api && window.api.getDesktopPath) {
    window.api.getDesktopPath().then(desktop => {
      defaultOutputDir = desktop;
      outputDirInput.value = desktop;
    });
  }

  // Sayfa genelinde tarayıcının varsayılan dosya açmasını engelle
  window.addEventListener('dragover', (e) => {
    e.preventDefault();
    e.stopPropagation();
  });

  window.addEventListener('drop', (e) => {
    e.preventDefault();
    e.stopPropagation();
  });

  /* ------------------ Sürükle - Bırak Olayları ------------------ */
  ['dragenter', 'dragover'].forEach(eventName => {
    dropzoneCard.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzoneCard.classList.add('drag-over');
    });
  });

  ['dragleave', 'drop'].forEach(eventName => {
    dropzoneCard.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzoneCard.classList.remove('drag-over');
    });
  });

  dropzoneCard.addEventListener('drop', async (e) => {
    e.preventDefault();
    e.stopPropagation();
    dropzoneCard.classList.remove('drag-over');

    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      const file = files[0];
      // Electron 33+ webUtils.getPathForFile
      let targetPath = '';
      if (window.api && window.api.getPathForFile) {
        targetPath = window.api.getPathForFile(file);
      }
      if (!targetPath && file.path) {
        targetPath = file.path;
      }

      if (targetPath) {
        await processSelectedPath(targetPath);
      } else {
        showError('⚠️ Dosya yolu okunamadı. Lütfen "Dosya Seç" veya "Klasör Seç" butonunu kullanarak dosyayı seçin.');
      }
    }
  });

  /* ------------------ Dosya / Klasör Seçme Butonları ------------------ */
  dropzoneCard.addEventListener('click', async (e) => {
    if (e.target.closest('button')) return;
    const filePath = await window.api.openFileDialog();
    if (filePath) {
      await processSelectedPath(filePath);
    }
  });

  selectFileBtn.addEventListener('click', async (e) => {
    e.stopPropagation();
    const filePath = await window.api.openFileDialog();
    if (filePath) {
      await processSelectedPath(filePath);
    }
  });

  selectFolderBtn.addEventListener('click', async (e) => {
    e.stopPropagation();
    const folderPath = await window.api.openFolderDialog();
    if (folderPath) {
      await processSelectedPath(folderPath);
    }
  });

  changeFileBtn.addEventListener('click', () => {
    resetToDropzone();
  });

  browseOutputDirBtn.addEventListener('click', async () => {
    const chosenDir = await window.api.openOutputDirDialog();
    if (chosenDir) {
      outputDirInput.value = chosenDir;
    }
  });

  /* ------------------ Pencere Boyut Şablonu ------------------ */
  sizePresetSelect.addEventListener('change', () => {
    const val = sizePresetSelect.value;
    if (val === '1280x800') {
      customWidthInput.value = 1280;
      customHeightInput.value = 800;
      fullscreenSwitch.checked = false;
    } else if (val === '1920x1080') {
      customWidthInput.value = 1920;
      customHeightInput.value = 1080;
      fullscreenSwitch.checked = false;
    } else if (val === '1024x768') {
      customWidthInput.value = 1024;
      customHeightInput.value = 768;
      fullscreenSwitch.checked = false;
    } else if (val === 'fullscreen') {
      fullscreenSwitch.checked = true;
    }
  });

  /* ------------------ Akıllı Doğrulama & İşleme ------------------ */
  async function processSelectedPath(targetPath) {
    if (!targetPath) return;

    // Geçici yükleniyor göstergesi
    dropzoneCard.style.opacity = '0.5';
    dropzoneCard.style.pointerEvents = 'none';

    try {
      // Doğrulama API'sini çağır
      const validation = await window.api.validatePath(targetPath);

      dropzoneCard.style.opacity = '1';
      dropzoneCard.style.pointerEvents = 'auto';

      if (!validation.valid) {
        showError(validation.error || 'Dosya türü veya içeriği bunu karşılamıyor.');
        return;
      }

      // Başarılı doğrulama
      currentProject = validation;
      appNameInput.value = validation.detectedName || 'WebUygulamasi';
      summaryTitle.textContent = `${validation.detectedName} (${validation.details || 'Doğrulandı'})`;
      summaryDetails.textContent = `Toplam ${validation.totalFiles || 1} dosya, ${validation.cssCount || 0} CSS, ${validation.scriptsCount || 0} JS, ${validation.imagesCount || 0} Görsel`;

      // Dropzone'u gizle, ayar formunu aç
      dropzoneCard.parentElement.classList.add('hidden');
      configSection.classList.remove('hidden');
    } catch (err) {
      dropzoneCard.style.opacity = '1';
      dropzoneCard.style.pointerEvents = 'auto';
      showError('Doğrulama sırasında bir hata oluştu: ' + err.message);
    }
  }

  function resetToDropzone() {
    currentProject = null;
    configSection.classList.add('hidden');
    dropzoneCard.parentElement.classList.remove('hidden');
  }

  /* ------------------ Derleme & Paketleme Başlat ------------------ */
  startBuildBtn.addEventListener('click', async () => {
    if (!currentProject) return;

    const appName = appNameInput.value.trim() || currentProject.detectedName || 'WebUygulamasi';
    const windowWidth = parseInt(customWidthInput.value, 10) || 1280;
    const windowHeight = parseInt(customHeightInput.value, 10) || 800;
    const isFullscreen = fullscreenSwitch.checked;
    const hideMenuBar = hideMenuSwitch.checked;
    const outputDir = outputDirInput.value.trim() || defaultOutputDir;

    // Konsol Modalını Aç
    terminalLog.textContent = '';
    buildPhaseText.textContent = 'Dosyalar hazırlanıyor ve Electron derleyicisi başlatılıyor...';
    buildModal.classList.remove('hidden');

    // Canlı Log Dinleyici
    window.api.onBuildLog((logLine) => {
      terminalLog.textContent += logLine + '\n';
      terminalLog.scrollTop = terminalLog.scrollHeight;

      if (logLine.includes('[1/4]')) buildPhaseText.textContent = 'Proje dosyaları analiz ediliyor...';
      if (logLine.includes('[2/4]')) buildPhaseText.textContent = 'Çalışma alanı ve varlıklar kopyalanıyor...';
      if (logLine.includes('[3/4]')) buildPhaseText.textContent = 'Electron yapılandırması (main.js, package.json) üretiliyor...';
      if (logLine.includes('[4/4]')) buildPhaseText.textContent = 'Windows Portable .EXE paketleniyor (electron-builder)...';
    });

    const result = await window.api.buildProject({
      sourcePath: currentProject.sourcePath,
      sourceType: currentProject.type,
      appName,
      windowWidth,
      windowHeight,
      isFullscreen,
      hideMenuBar,
      outputDir
    });

    buildModal.classList.add('hidden');

    if (result.success) {
      generatedExePath = result.exePath;
      successExePath.textContent = result.exePath;
      successModal.classList.remove('hidden');
    } else {
      showError(result.error || 'Derleme sırasında bilinmeyen bir hata oluştu.');
    }
  });

  /* ------------------ Sonuç Modal Aksiyonları ------------------ */
  openExeNowBtn.addEventListener('click', () => {
    if (generatedExePath) {
      window.api.openExe(generatedExePath);
    }
  });

  showInFolderBtn.addEventListener('click', () => {
    if (generatedExePath) {
      window.api.showInFolder(generatedExePath);
    }
  });

  newConversionBtn.addEventListener('click', () => {
    successModal.classList.add('hidden');
    resetToDropzone();
  });

  /* ------------------ Hata Modalı ------------------ */
  function showError(msg) {
    errorModalMessage.textContent = msg;
    errorModal.classList.remove('hidden');
  }

  closeErrorModalBtn.addEventListener('click', () => {
    errorModal.classList.add('hidden');
  });

})();
