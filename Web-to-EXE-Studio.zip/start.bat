@echo off
chcp 65001 > nul
title Web2Exe Studio Başlatıcı

echo ===================================================
echo     WEB2EXE STUDIO - WINDOWS EXE DÖNÜŞTÜRÜCÜ
echo ===================================================
echo.

if not exist node_modules\electron (
    echo [1/2] Gerekli paketler ilk kez kuruluyor (npm install)...
    call npm install
    echo.
)

echo [2/2] Web2Exe Studio başlatılıyor...
npx electron .
