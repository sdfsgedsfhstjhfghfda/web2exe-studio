/**
 * Build Worker - electron-builder'ı Electron ortamının DIŞINDA çalıştıran bağımsız Node.js scripti
 * main.js tarafından child_process.fork() ile çağrılır.
 * Parametreler stdin JSON olarak gelir, loglar process.send() ile ana sürece gönderilir.
 */

process.on('message', async (options) => {
  const builder = require('electron-builder');
  const path = require('path');

  const {
    projectDir,
    distFolder,
    safeSlug,
    appName,
    cleanFileName: cleanFileNameStr,
    windowWidth,
    windowHeight,
    isFullscreen,
    hideMenuBar,
    entryHtmlName
  } = options;

  function log(msg) {
    process.send({ type: 'log', msg });
  }

  function cleanFileName(name) {
    if (!name) return 'Uygulama';
    return name.replace(/[\\/:*?"<>|\s]/g, '-').replace(/-+/g, '-');
  }

  try {
    log(`⚡ [4/4] Windows .EXE Derleniyor (electron-builder)...`);
    log(`⏳ Lütfen bekleyin, taşınabilir EXE sıkıştırılıyor...`);

    const builtFiles = await builder.build({
      targets: builder.Platform.WINDOWS.createTarget(['portable']),
      config: {
        appId: `com.web2exe.${safeSlug}`,
        productName: appName,
        asar: false,
        directories: {
          app: projectDir,
          output: distFolder
        },
        win: {
          target: ['portable'],
          artifactName: `${cleanFileName(appName)}-Portable.exe`
        }
      }
    });

    log(`📦 Oluşturulan dosyalar: ${builtFiles.join(', ')}`);
    process.send({ type: 'done', files: builtFiles });
  } catch (err) {
    process.send({ type: 'error', message: err.message });
  }
});
